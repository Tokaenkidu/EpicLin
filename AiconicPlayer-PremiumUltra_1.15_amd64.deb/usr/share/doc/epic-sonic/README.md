# AiconicPlayer (com.epicwebdesignstudio.epicsonic)

## Cel
Pełnoprawny odtwarzacz muzyki nowej generacji dla Linux Mint (Cinnamon): własny silnik audio, biblioteka SQLite, oceny/ulubione, 5 skórek, EQ 10-pasmowy, wizualizacje FFT, MPRIS, .deb.

## Status
✅ **v1.01 — silnik AURA-X** (Adaptive Universal Restoration & Audio eXpansion Engine). Nowy silnik dźwięku, który najpierw *słucha nagrania* (AUDIO DNA → wskaźnik jakości Q 0–100), a dopiero potem decyduje, ile naprawiać/poprawiać: dobry FLAC zostaje prawie nietknięty, stary MP3 128 kb/s dostaje realną pomoc. Tryby OFF · PURE · RESTORE · ENHANCE · HYPER · AUTO, profile Original / Balanced / Powerful / Night, pętla samokorekty SCAL, limiter true-peak −1 dBTP, pamięć DNA utworów. Kod: `src/audio/aurax/` (Rust, desktop) i `android/web/aurax.js` (AudioWorklet: Android + iPhone). Opis: `docs/AURA-X.md`. Testy: `cargo test aurax`, `node android/tools/aurax_test.js`.
Wersje 1.01: Free = bez AURA-X, Premium = wszystkie tryby oprócz HYPER, PremiumUltra+ = wszystko.

Wcześniej:
🚧 v0.20 — Windows pod **Wine** działa: program wykrywa Wine (klucz `HKCU\Software\Wine`) → tekst przez fontconfig (`PANGOCAIRO_BACKEND=fc`) i wyjście dźwięku `directsoundsink` (WASAPI2 nie startuje pod Wine). Okładka w dolnym pasku ma stały rozmiar 58 px. Wcześniej v0.18: naprawa jakości dźwięku (`stereo` → `audiomixmatrix`) + 4 jasne skórki; v0.17 jedno okno; v0.15 edycje Free/Premium/PremiumUltra+.
Instalacja Windows pod Wine: `WINEPREFIX=~/.wine-aiconic wine AiconicPlayer-PremiumUltra-Setup-0.0.20.exe` (Bluetooth i MPRIS są tylko na Linuksie).

## Zawartość
- `src/` moduły: config, ui, themes, audio, library, database, playback, visualizer, mpris
- `assets/icons`, `packaging/` (Faza 12)

## Wymagania
sudo apt install libgtk-4-dev libadwaita-1-dev libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev libgstreamer-plugins-bad1.0-dev

## Jak użyć
`cargo run` (dev), `epic-sonic --debug` (logi, później)

## Data
2026-09-24

## Windows (instalator)
`packaging/windows/build-windows.sh` w MSYS2 MINGW64 (albo workflow `.github/workflows/windows.yml` na GitHub Actions) buduje `dist/EPIC-SONIC-Setup-<wersja>.exe` (Inno Setup). Nietestowane na Windows — pierwszy build wymaga weryfikacji.

## Kotek
`src/ui/cat.rs` — kotek chodzący po górnej krawędzi playera; po 45 s ciągłego grania siada na środku i macha ogonem; ruch myszy go budzi. Zmienne testowe: EPIC_SETTLE_SECS, EPIC_AUTOPLAY, EPIC_CAT_IGNORE_MOUSE, EPIC_CAT_DEBUG.
